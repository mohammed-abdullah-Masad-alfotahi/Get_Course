﻿using System.Windows.Forms;

namespace L3
{
    internal class From2 : Form
    {
    }
}