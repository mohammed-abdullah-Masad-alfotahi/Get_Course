﻿using System;
using System.Windows.Forms;
namespace L3
{ public partial class from2 : Form
    { double num1, num2, result;
        string[] op = { "+", "-", "*", "/" };
        public from2()
        {
            InitializeComponent();
           // this.comb.Items.AddRange(op);
            comb.Items.AddRange(op);
            //comb.Items.Add("+");
            //comb.Items.Add("-");
            //comb.Items.Add("*");
            //comb.Items.Add("/");
           // comb.SelectedIndex = 0;
        }
        private void button1_Click(object sender, EventArgs e)
        { this.Close(); }
        private void Form2_Load(object sender, EventArgs e)
        {
            txtr.ReadOnly = true;
            comb.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void txtn1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtn1.Text = txtn2.Text = txtr.Text ="";
        }
        private void button3_Click(object sender, EventArgs e)
        {
           try
            {
                num1 = Convert.ToDouble(txtn1.Text);
            }
            catch(Exception)
            {
                MessageBox.Show("العدد الاول غير صالح", "تحذير", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                txtn1.Text = "";
                txtn1.Focus();
                return;
            }
            try
            {
                num2 = Convert.ToDouble(txtn1.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("العدد الثاني غير صالح", "تحذير", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                txtn2.Text = "";
                txtn2.Focus();
                return;
            } bool f = true;
            switch(comb.SelectedIndex)
            {
                default: break;
                case 0:result = num1 + num2; break;

                case 1: result = num1 -num2; break;

                case 2: result = num1 * num2; break;
                case 3: 
                    if(num2!=0)
                    {
                        result = num1 / num2;
                        break;
                    }
                    else
                    {
                        MessageBox.Show("لايمكنك القسمة على صفر") ;
                        f = false;
                        txtr.Text = null;
                        break;
                    }
            }
            if (f)
                txtr.Text = result.ToString();

        }
    }
}
