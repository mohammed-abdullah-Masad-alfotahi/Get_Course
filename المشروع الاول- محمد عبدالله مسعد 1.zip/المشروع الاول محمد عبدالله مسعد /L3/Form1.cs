﻿using System;
using System.Windows.Forms;
using System.Drawing;
namespace L3
{
    public partial class frmOperation : Form
    {
        double x, y, z;
        string[] op = { "+", "-", "*", "/" };
        public frmOperation()
        {
            InitializeComponent();
            enabled(false);
            txtResult.BackColor = Color.Red;

        }
        public void operation(double n1, double n2,string op)
        {
            switch(op)
            {
                case "+":
                    txtResult.Text = (n1 + n2).ToString();
                    break;
                case "-":
                    txtResult.Text = (n1 -n2).ToString();
                    break;
                case "*":
                    txtResult.Text = (n1 *n2).ToString();
                    break;
                case "/":
                    if (n2 != 0)
                        txtResult.Text = (n1 / n2).ToString();
                    else
                        MessageBox.Show("لا يمكن القسمة على صفر","تحذير",MessageBoxButtons.OK,MessageBoxIcon.Warning,MessageBoxDefaultButton.Button1);
                    break;
                default:
                    MessageBox.Show("أكتملت العمليات بنجاح", "تحذير", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
                    break;
                   
            }
        }

        private void frmOperation_Load(object sender, EventArgs e)
        {
        //  btnAdd.Enabled = btnSub.Enabled = btnMult.Enabled = btnDiv.Enabled = false;
           txtN1.TextChanged+= txtN2_TextChanged;
            txtResult.ReadOnly=true;

            //this.Text = "الأة حاسبة بسيطة";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //iاnt x = Convert.ToInt32(txtN1.Text);
            //int y = int.Parse(txtN2.Text);
            //int z = x + y;
            // txtResult.Text =( Convert.ToInt32(txtN1.Text) + int.Parse(txtN2.Text)).ToString();
            //if (txtN1.Text.Trim() == "")
            //{
            //    MessageBox.Show("أدخل العدد الاول");
            //    txtN1.Focus();
            //    return;

            //}

            //else if ((txtN2.Text.Trim() == ""))
            //{
            //    MessageBox.Show("أدخل العدد الثاني");
            //    txtN2.Focus();
            //}
            //else

            // txtResult.Text = (Convert.ToDouble(txtN1.Text) + double.Parse(txtN2.Text)).ToString();
            operation(Convert.ToDouble(txtN1.Text), double.Parse(txtN2.Text), "+");
        
        //    else
        //        MessageBox.Show("الرجاء الادخل ", "تحذير", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);

        }

        private void txtN1_TextChanged(object sender, EventArgs e)
        { //تم تضعيفة مع الحدث التابع لة اثاني
            //if (txtN1.Text.Trim() != "" && txtN2.Text.Trim() != "")
            //{
            //    btnAdd.Enabled =btnSub.Enabled=btnMult.Enabled=btnDiv.Enabled=true;
            //}
            //else
            ////  btnAdd.Enabled = (txtN1.Text != "") && (txtN2.Text != "");
            //btnAdd.Enabled = btnSub.Enabled = btnMult.Enabled = btnDiv.Enabled = false;

         
            //استدعاء الدالة
            //bool f=txtN1.Text.Trim()!=""&&txtN2.Text.Trim()!="";
            //enabled(f);

        }
        private void txtN2_TextChanged(object sender,EventArgs e)
        {
            //if (txtN1.Text != "" && txtN2.Text != "")
            //{
            //      btnAdd.Enabled= btnSub.Enabled =btnMult.Enabled=btnDiv.Enabled=true;

            //}
            //else
            //      btnAdd.Enabled= btnSub.Enabled =btnMult.Enabled=btnDiv.Enabled = false;
            //هذا اختصار لسابق
          //  btnAdd.Enabled= btnSub.Enabled =btnMult.Enabled=btnDiv.Enabled= (txtN1.Text .Trim()!= "") && (txtN2.Text .Trim()!= "");
            bool f = txtN1.Text.Trim() != "" && txtN2.Text.Trim() != "";
            enabled(f);


        }

        private void txtN1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8) && (e.KeyChar != '-')&&(e.KeyChar != '.'))
            //{
            //    e.Handled = true;
            //}
            isnumber(e);


        }
        private void txtN2_KeyPress(object sender,KeyPressEventArgs e)
        {
            //if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8) && (e.KeyChar != '-')&&(e.KeyChar!='.'))
            //{
            //    e.Handled = true;
            //}
            isnumber(e);
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
          //  txtResult.Text = (Convert.ToDouble(txtN1.Text) -double.Parse(txtN2.Text)).ToString();
          operation(Convert.ToDouble(txtN1.Text) , double.Parse(txtN2.Text),"-");

        }
        private void btnDiv_Click(object sender, EventArgs e)
        { if(double.Parse(txtN2.Text)!=0)
            txtResult.Text = (Convert.ToDouble(txtN1.Text)/double.Parse(txtN2.Text)).ToString();
        else
            MessageBox.Show("لا يمكن القسمة على صفر", "تحذير", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            txtResult.Text = (Convert.ToDouble(txtN1.Text) * double.Parse(txtN2.Text)).ToString();
        }
        public void enabled(bool f)
        {
            btnAdd.Enabled = btnSub.Enabled = btnMult.Enabled = btnDiv.Enabled = f;


        }
        public void isnumber(KeyPressEventArgs e)
        {
            if ((e.KeyChar < 48 || e.KeyChar > 57) && (e.KeyChar != 8) && (e.KeyChar != '-') && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }


        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDelet_Click(object sender, EventArgs e)
        {
            txtN1.Text = txtN2.Text =txtResult.Text=null;
        }
    }
}
