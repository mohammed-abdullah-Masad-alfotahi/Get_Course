﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace lab6_H
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }
        int i = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox1.Image = new Bitmap(i.ToString() + ".png");
            i++;
            if (i >=9)
                i = 0;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
            timer1.Enabled = true;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
