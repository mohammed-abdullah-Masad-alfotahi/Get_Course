﻿using System;
using System.Windows.Forms;

namespace lab6_H
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          //  timer1.Interval = 10;
            timer1.Start();
            timer1.Enabled = true;
        }
        int s = -1, m = 0, h = 0, y = 0,d=0;

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            s++;
            if (s > 9)
            {
                label1.Text = s.ToString();

            }
            else
            {
                label1.Text = "0" + s.ToString();
            }
            if (s >= 59)
            {
                s = 0;
                timer1.Interval = 100;
                m++;
                if (m > 9)
                {
                    label2.Text = m.ToString();

                }
                else
                {
                    label2.Text = "0" + m.ToString();
                }

            }

            if (m >= 59)
            {
                m = 0;
              //  timer1.Interval = 100;
                h++;
                if (h > 9)
                {
                    label3.Text = h.ToString();

                }
                else
                {
                    label3.Text = "0" + h.ToString();
                }
                if (h >= 24)
                {
                    h = 0;
                  //  timer1.Interval = 100;
                    d++;
                    if (d > 9)
                    {
                        label4.Text = d.ToString();

                    }
                    else
                    {
                        label3.Text = "0" + h.ToString();
                    }

                }
            }
        }

        

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();

        }
      
    }
}
