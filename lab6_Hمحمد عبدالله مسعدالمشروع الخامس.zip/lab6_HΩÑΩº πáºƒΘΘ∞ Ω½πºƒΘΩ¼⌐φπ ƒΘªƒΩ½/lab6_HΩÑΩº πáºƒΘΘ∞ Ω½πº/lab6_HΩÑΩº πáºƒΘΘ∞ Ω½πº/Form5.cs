﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab6_H
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Bitmap MyBitm = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            int x, y;
            for(x=0; x<200;x++)
            {
                y = x;
                // MyBitm.SetPixel(x, y, Color.Green);
                //  MyBitm.SetPixel(x, 80, Color.Green);
                MyBitm.SetPixel(80,y, Color.Green);
              

            }
            pictureBox1.Image = MyBitm;

        }

        private void button2_Click(object sender, EventArgs e)
        {
           this. Close();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.CreateGraphics().DrawRectangle(Pens.Red,40, 40, 40, 40);
            pictureBox1.CreateGraphics().DrawRectangle(Pens.Red, 40, 40, 40, 40);
        }
    }
}
