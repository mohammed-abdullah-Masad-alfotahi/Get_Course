﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab6_H
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }
        int Count = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            Count++;
            if(Count<=9)
            {
                pictureBox1.Image = Image.FromFile(Count.ToString() + ".png");
                BackgroundImage = Image.FromFile(Count.ToString() + ".png");
            }
            else
            {
                pictureBox1.Image = Image.FromFile(Count.ToString() + ".png");
                BackgroundImage = Image.FromFile(Count.ToString() + ".png");
                // Count = 0;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Count--;
            if (Count <0)
            
                Count = 9;
            
                   
                pictureBox1.Image = Image.FromFile(Count.ToString() + ".png");
                BackgroundImage = Image.FromFile(Count.ToString() + ".png");
            
 




        }

        private void Form9_Load(object sender, EventArgs e)
        {
            BackgroundImage = Image.FromFile("c#.png");
            BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            
        }
    }
}
