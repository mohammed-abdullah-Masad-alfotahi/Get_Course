﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab6_H
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            openFileDialog1.ShowDialog();
            openFileDialog1.Filter = "Imag Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif|All Files|*.*";
            if(openFileDialog1.ShowDialog()==DialogResult.OK)
            {
                // pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
                Bitmap MyBitmap = new Bitmap(openFileDialog1.FileName);
                pictureBox1.Image = MyBitmap;
            }


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            openFileDialog2.ShowDialog();
            openFileDialog2.Filter = "Imag Files|*.jpg;*.png;|All Files|*.*";
            if (openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                // pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
                string BM = openFileDialog2.FileName;
                Bitmap MyBitmap = new Bitmap(BM);
                pictureBox1.Image = MyBitmap;
                textBox1.Text = BM; 


            }
        }

        private void openFileDialog2_FileOk(object sender, CancelEventArgs e)
        {

        }

       
    }
}
