﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication41
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
                textBox1.Text += checkBox1.Text+"\r\n";
            if (checkBox2.Checked)
                textBox1.Text += checkBox2.Text+"\r\n";
            if (checkBox3.Checked)
                textBox1.Text += checkBox3.Text + "\r\n";
            if (checkBox4.Checked)
                textBox1.Text += checkBox4.Text + "\r\n";
            if (checkBox5.Checked)
                textBox1.Text += checkBox5.Text + "\r\n";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(radioButton6.Checked)
                label1.ForeColor=Color.Red;
            else if (radioButton7.Checked)
                label1.ForeColor = Color.Yellow;
            else   if (radioButton8.Checked)
                label1.ForeColor = Color.Green;
            else if (radioButton9.Checked)
                label1.ForeColor = Color.Blue;
            else   if (radioButton10.Checked)
                label1.ForeColor = Color.Black;


            if (radioButton1.Checked)
                label1.BackColor = Color.Red;
            else if (radioButton2.Checked)
                label1.BackColor = Color.Yellow;
            else if (radioButton3.Checked)
                label1.BackColor = Color.Green;
            else if (radioButton4.Checked)
                label1.BackColor = Color.Blue;
            else if (radioButton5.Checked)
                label1.BackColor= Color.Black;


        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void button4_Click(object sender, EventArgs e)
        {      if( panel1.Enabled == false)
            panel1.Enabled = true;
            else
            panel1.Enabled = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {   if( panel1.Visible == false)
            panel1.Visible = true;
            else
            panel1.Visible = false;
        }
    }
}
